# BE - the Banglish programming language

**BE** is a programming language of its own, like Python or C, where you write code with Bangla words in English letters. "My name" is `amar_nam`, print is `dekhao`, if is `jodi`, a function is `kaj`. Everything BE shows back to you (output, error messages, websites, apps) is in English.

```
dhoro amar_nam = "Shuvo"
dekhao "My name is {amar_nam}"

shreni Manush {
    kaj shuru(nam) {
        ei.nam = nam
    }
    kaj parichoy() {
        ferot "Hi, I am {ei.nam}."
    }
}

dhoro rahim = Manush("Rahim")
dekhao rahim.parichoy()
```

Created by **Jonayed Hossain**, 2026.

## What you can build

- **Programs** that run in the terminal: `be run amar_program.be`
- **Websites** with BE's own web server: pages, forms, JSON APIs, CSS folders
- **Apps** with windows, text, buttons, input boxes, rows, colors and keyboard keys
- **Interactive web pages**: write BE inside `<script type="text/be">` and control the page
- **Anything Python or JavaScript can do**, through their libraries: `python("math")`, `js("Math")`

Every word you type is Banglish: keywords, ready-made functions, website words, app words and web page words. Apps and websites run on a computer (`be run`: apps open as real windows, websites at http://localhost:8000) and in the BE Playground in a browser, where they show in a preview.

A full example: `examples/app/calculator.be` is a complete calculator app in BE. Run it with `be run examples/app/calculator.be`, or pick "App: calculator" in the Playground.

## Install

**The BE installer (no Python needed).** On the project's GitHub page, open **Releases** and download:

- Windows: `BE-Setup.exe`. Run it, then open a new terminal and type `be --version`.
- Mac: `be-macos`, Linux: `be-linux`. Rename it to `be` and put it in a folder on your PATH.

**With Python 3.11 or newer** (for working on BE itself, or to use other Python libraries with `python("name")`):

```
pip install -e .
```

(After BE is published on PyPI: `pip install be-lang`)

## Run

```
be run amar_program.be   # run a file
be amar_program.be       # same thing
be                       # interactive mode, type code line by line
be --version
```

If the `be` command is not found, use `python -m be amar_program.be` instead.

## Keywords

| Keyword | Meaning | Example |
| --- | --- | --- |
| `dhoro` | make a variable (optional) | `dhoro x = 5` or just `x = 5` |
| `dekhao` | print | `dekhao "Hello", x` |
| `jodi` / `tahole` / `nahole` | if / then (optional) / else | `jodi x > 5 tahole { ... } nahole { ... }` |
| `jotokkhon` | while | `jotokkhon x < 10 { ... }` |
| `ghuro ... theke` | count | `ghuro i = 1 theke 10 { ... }` |
| `porjonto`, `dhap` | up to (optional), step | `ghuro i = 0 theke 10 porjonto dhap 2 { ... }` |
| `ghuro ... bar` | repeat | `ghuro 5 bar { ... }` |
| `protiti ... theke` | for each | `protiti f fol_guli theke { ... }` |
| `thamo` / `agao` | break / continue | `thamo` |
| `kaj` / `ferot` | function / return | `kaj jog(a, b = 1) { ferot a + b }` |
| `shreni`, `ei`, `upor` | class, this, parent class | `shreni Chhatro theke Manush { ... }` |
| `chesta ... nahole` | try / catch | `chesta { ... } nahole bhul { dekhao bhul }` |
| `chhuro` | throw an error | `chhuro "Age can't be negative"` |
| `anao` | use another file | `anao "hishab.be"` |
| `sotti` / `mittha` / `kichuna` | true / false / null | `dhoro thik = sotti` |
| `ebong` / `othoba` / `na` | and / or / not | `jodi x > 1 ebong na thik { ... }` |
| `moddhe` | is inside | `jodi "a" moddhe ["a", "b"] { ... }` |

More: `"Total: {x + 1}"` puts values inside text, `kaj (x) { ferot x * 2 }` is a function without a name, `obhibadon(nam = "Shuvo")` passes an input by name, and a long line can continue on the next line when that line starts with `+`, `*`, `.` or `ebong`.

If you type a word from English or Python, BE points you to the Banglish one: `print("hi")` says *Did you mean 'dekhao'?*, `len(x)` says *'lomba'*, `server()` says *'website'*.

## Ready-made functions

| Function | What it does |
| --- | --- |
| `lomba(x)` | length of text, a list or a dictionary |
| `jiggesh(prosno)` | ask the user, returns text |
| `shonkha(x)` / `lekha(x)` | to a number / to text |
| `dhoron(x)` | type: `number`, `text`, `list`, `dictionary`, ... |
| `jukto(talika, x)` / `bad_dao(talika)` | add to the end / remove the last item |
| `boro(...)` / `choto(...)` / `jogfol(talika)` | biggest / smallest / total |
| `shajao(talika)` / `shajao(talika, kaj)` / `ulta(x)` | sorted copy / sorted by something / backwards |
| `bhag(lekha, chinho)` / `jora(talika, chinho)` | split / join |
| `bodlao(lekha, ager, notun)` | replace |
| `boro_hater(t)` / `choto_hater(t)` / `parishkar(t)` | CAPITALS / small letters / trim spaces |
| `kothay(x, jinish)` | position of an item, or -1 |
| `chabi(dict)` / `man(dict)` | keys / values |
| `gol(x)`, `borgomul(x)`, `poromman(x)`, `elomelo(a, b)` | round, square root, absolute value, random number |
| `json_banao(x)` / `json_porho(lekha)` | to JSON text / from JSON text |
| `shomoy()` | current time in seconds |

Everywhere (computer and browser): `website()` and `uttor(...)` for websites, `janala()` for apps.

On a computer only: `file_porho`, `file_lekho`, `file_jog`, `file_ache` for files, `web_theke(url)` to download, `ghumao(second)` to wait, and `python("name")` for Python libraries.

In a web page only: `khojo("#id")`, `shob_khojo(".class")`, `banao("li")`, `pore(second, kaj)`, `notun(js("Date"))` and `js("name")` for JavaScript libraries.

## A website in BE

```
dhoro amar_site = website()

amar_site.pata("/", kaj (r) {
    ferot "<h1>Hello from BE</h1><a href='/hello/Rahim'>Say hello</a>"
})

amar_site.pata("/hello/:nam", kaj (r) {
    ferot "<p>Hello, {r.ongsho.nam}!</p>"
})

amar_site.pata("/api", kaj (r) {
    ferot {"thik": sotti, "shonkha": [1, 2, 3]}     # dictionaries and lists are sent as JSON
})

amar_site.chalao(8000)                              # open http://localhost:8000
```

| Website words | What they do |
| --- | --- |
| `website()` | a website |
| `site.pata("/page", kaj (r) { ... })` | a page (pata). Add `"POST"` for a page that a form sends to |
| `site.fileguli("/static", "public")` | the CSS, JavaScript and other files in a folder |
| `site.chalao(8000)` | start the website at http://localhost:8000 |
| `site.porikkha("/page")` | test a page without a browser: gives `abostha` (status), `dhoron` (type) and `lekha` (the page) |
| `uttor("Not found", 404)` | an answer with its own status code (and type) |
| `r.ongsho.nam` | the `:nam` part of the address |
| `r.ghor.nam` | what a visitor typed in a form's box called `nam` |
| `r.prosno.x` | the `?x=...` part of the address |
| `r.thikana`, `r.poddhoti`, `r.json`, `r.lekha`, `r.tottho` | the address, `"GET"` or `"POST"`, sent JSON, the sent text, the request's details |

See `examples/website/` for a notes website with a form, a CSS folder and a JSON API.

## An app in BE

```
dhoro amar_janala = janala("Counter", 360, 300)
dhoro lekha_ti = amar_janala.lekha("Count: 0").akar(22)
dhoro gona = 0

dhoro sari = amar_janala.sari()              # a row: its buttons sit side by side
sari.botam("Add 1", kaj () {
    gona += 1
    lekha_ti.bodlao("Count: {gona}")
})
sari.botam("Reset", kaj () {
    gona = 0
    lekha_ti.bodlao("Count: 0")
}).pechon("#0d6b49").rong("white")

amar_janala.chabi_chap(kaj (chabi_ti) {      # the keyboard: chabi_ti is "a", "5", "Enter", ...
    jodi chabi_ti == " " { lekha_ti.bodlao("Count: {gona} (space pressed)") }
})
amar_janala.chalao()
```

| App words | What they do |
| --- | --- |
| `janala("Title", width, height)` | a window |
| `w.lekha(lekha)`, `w.botam(lekha, kaj)`, `w.ghor(lekha)` | text, a button, an input box (read it with `.man()`) |
| `w.sari()` | a row: what you add to it sits side by side |
| `w.pechon(rong)`, `w.chabi_chap(kaj)`, `w.pore(second, kaj)` | background color, keyboard, run later |
| `x.bodlao(lekha)`, `x.man()` | change / read the text of a text, button or box |
| `x.rong(rong)`, `x.pechon(rong)`, `x.akar(akar)`, `x.dane()` | text color, background, text size, text on the right |
| `w.chalao()`, `w.bondho()` | open the window / close it |

See `examples/app/` for the counter and the full calculator.

## BE inside a web page

```html
<button id="botam">Click me</button>
<p id="lekha"></p>
<script src="be-web.js"></script>
<script type="text/be">
    dhoro gona = 0
    khojo("#botam").chap(kaj () {
        gona += 1
        khojo("#lekha").bodlao("Clicked {gona} times").rong("green")
    })
</script>
```

| Page words | What they do |
| --- | --- |
| `khojo("#id")`, `shob_khojo(".class")`, `banao("li")` | find one element, find all, make a new one |
| `el.bodlao(lekha)`, `el.man()`, `el.html(lekha)` | change its text / read its text or what was typed / set its HTML |
| `el.chap(kaj)`, `el.chabi_chap(kaj (chabi_ti) { ... })` | run a kaj when it is clicked / when a key is pressed in it |
| `el.jog(jinish)`, `el.muchho()`, `el.bad()` | add something inside it / empty it / remove it from the page |
| `el.chinho("done", sotti)`, `el.lukao(sotti)` | mark it (a CSS class) / hide it |
| `el.rong(rong)`, `el.pechon(rong)`, `el.akar(akar)`, `el.dane()` | text color, background, text size, text on the right |

`be-web.js` is in the `playground` folder. See `examples/browser/index.html` for a to-do list. A `janala()` app or a `website()` also works on your own page: it appears inside an element with `id="be-app"`, or at the end of the page.

## Web playground

Open `playground/index.html` in a browser, or publish it with GitHub Pages so anyone can try BE from a link. Programs, apps and websites all run there. Apps and websites show in a preview under the code, and a website's links, forms and `fetch()` calls are answered by your BE code, right in the browser.

## Learn BE

Open `playground/learn.html` in a browser: the whole course (`learn/course.md`) on one side and a live BE workspace on the other.

- **▶ Try it** on any example puts it in the editor and runs it.
- **Try it exercises** (30 of them): click **Start**, write the code, then **Check my code**. BE runs it with test answers and says what is right and what to fix. **Show answer** is there for when you are stuck.
- **Files**: several files in tabs (`main.be`, `hishab.be`, ...), so `anao` works, and `file_lekho` / `file_porho` save into a pretend folder, so Lesson 12 runs in the browser too.
- **Apps, websites and HTML pages** open in the preview under the code.
- **Progress and code** stay in the browser. It works on phones (Lesson and Code tabs at the top).

The lessons come from `learn/course.md`: after changing the course, run `python tools/sync.py` to rebuild `playground/lessons.js`. How each exercise is checked is in `tools/build_learn.py`.

## Tests

```
pip install pytest
python -m pytest
```

## Changing keywords

Edit `be/keywords.py`, then run:

```
python tools/sync.py
python -m pytest
```

## Making the BE installer

Every time you publish a release on GitHub, GitHub builds BE for Windows (`BE-Setup.exe` and `be-windows.exe`), Mac and Linux and adds the files to the release page (`.github/workflows/build-be.yml`). You can also build it on your own computer:

```
python -m pip install pyinstaller
python tools/build_exe.py           # makes dist/be-windows.exe (or be-macos, be-linux)
iscc installer/be.iss               # Windows only, with Inno Setup: makes dist/BE-Setup.exe
```

Inside the installed BE, `python("name")` can use Python's standard library (`math`, `datetime`, `json`, `random`, ...). For other Python libraries, install BE with pip instead.

## Project layout

```
be/keywords.py           every keyword
be/lexer.py              text -> tokens
be/parser.py             tokens -> syntax tree
be/interpreter.py        runs the syntax tree
be/builtin_functions.py  lomba, shajao, json_banao, ...
be/computer.py           websites, apps (windows), files, Python libraries
be/values.py             how values print and compare
be/suggest.py            "Did you mean...?" hints, including English -> Banglish
be/errors.py             error messages
be/cli.py                the `be` command
examples/                sample programs (website/, app/, browser/, python/ inside)
tests/                   automatic tests
playground/              BE in JavaScript (be.js: also apps, websites and page words), be-web.js, the playground and learn.html
tools/sync.py            keeps VS Code colors, the JavaScript version, the lessons and the installer in step
tools/build_learn.py     turns learn/course.md into the Learn BE page's lessons and exercise checks
learn/course.md          the Learn BE course (15 lessons, projects, answers)
tools/build_exe.py       builds BE as its own program (be.exe), no Python needed to use it
installer/be.iss         the Windows installer (BE-Setup.exe)
.github/workflows/       GitHub builds the installer for every release
vscode-be/               VS Code syntax colors for .be files
```

## License

MIT License. Copyright (c) 2026 Jonayed Hossain. See [LICENSE](LICENSE).
